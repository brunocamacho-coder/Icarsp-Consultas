var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var process_payment_exports = {};
__export(process_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(process_payment_exports);
var import_crypto = __toESM(require("crypto"), 1);
var import_supabase_js = require("@supabase/supabase-js");
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { placa, ...formData } = body;
    if (!placa) {
      return { statusCode: 400, body: JSON.stringify({ error: "Placa obrigat\xF3ria" }) };
    }
    const accessToken = process.env.MP_ACCESS_TOKEN;
    const siteUrl = process.env.SITE_URL;
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!accessToken || !siteUrl) {
      return { statusCode: 500, body: JSON.stringify({ error: "Configura\xE7\xE3o incompleta do servidor" }) };
    }
    const placaNormalizada = String(placa).replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const payload = {
      ...formData,
      transaction_amount: 14.99,
      description: `Consulta veicular placa ${placaNormalizada}`,
      external_reference: placaNormalizada,
      notification_url: `${siteUrl}/.netlify/functions/mp-webhook`
    };
    const mpResponse = await fetch("https://api.mercadopago.com/v1/payments", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "X-Idempotency-Key": import_crypto.default.randomUUID()
      },
      body: JSON.stringify(payload)
    });
    const mpData = await mpResponse.json();
    if (!mpResponse.ok) {
      return {
        statusCode: mpResponse.status === 429 ? 429 : 500,
        body: JSON.stringify({ error: mpData.message || "Erro ao processar pagamento", details: mpData })
      };
    }
    if (supabaseUrl && supabaseKey) {
      const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey);
      await supabase.from("vehicle_reports").upsert({
        payment_id: String(mpData.id),
        placa: placaNormalizada,
        status: mpData.status || "pending",
        customer_email: formData.payer?.email || null,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    return {
      statusCode: 200,
      body: JSON.stringify(mpData)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erro interno", details: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
