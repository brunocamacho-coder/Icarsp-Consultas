var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var check_mp_payment_exports = {};
__export(check_mp_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(check_mp_payment_exports);
async function handler(event) {
  try {
    if (event.httpMethod !== "GET") {
      return {
        statusCode: 405,
        body: JSON.stringify({
          error: "M\xE9todo n\xE3o permitido"
        })
      };
    }
    const paymentId = event.queryStringParameters?.payment_id;
    const tipo = event.queryStringParameters?.tipo || "";
    if (!paymentId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: "payment_id obrigat\xF3rio"
        })
      };
    }
    const accessToken = process.env.MP_ACCESS_TOKEN;
    const siteUrl = process.env.SITE_URL;
    if (!accessToken) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "MP_ACCESS_TOKEN n\xE3o configurado"
        })
      };
    }
    if (!siteUrl) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "SITE_URL n\xE3o configurado"
        })
      };
    }
    const mpResponse = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    const mpData = await mpResponse.json();
    if (!mpResponse.ok) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Erro ao consultar pagamento no Mercado Pago",
          details: mpData
        })
      };
    }
    const status = mpData.status || "unknown";
    const pago = status === "approved";
    const isContrato = tipo === "contrato" || tipo === "contrato_reserva";
    if (pago && !isContrato) {
      try {
        await fetch(`${siteUrl}/.netlify/functions/generate-report`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            paymentId: String(paymentId)
          })
        });
      } catch (generateError) {
        console.error("Erro ao disparar generate-report:", generateError);
      }
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        payment_id: String(paymentId),
        status,
        pago
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Erro interno ao verificar pagamento",
        details: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
