var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var create_mp_payment_exports = {};
__export(create_mp_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_mp_payment_exports);
var import_crypto = __toESM(require("crypto"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey);
async function handler(event) {
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" })
      };
    }
    const { placa, email } = JSON.parse(event.body || "{}");
    if (!placa) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Placa obrigat\xF3ria" })
      };
    }
    const accessToken = process.env.MP_ACCESS_TOKEN;
    const siteUrl = process.env.SITE_URL;
    if (!accessToken) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "MP_ACCESS_TOKEN n\xE3o configurado" })
      };
    }
    if (!siteUrl) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "SITE_URL n\xE3o configurado" })
      };
    }
    if (!supabaseUrl) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "SUPABASE_URL n\xE3o configurado" })
      };
    }
    if (!supabaseKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "SUPABASE_SERVICE_ROLE_KEY n\xE3o configurado" })
      };
    }
    const placaNormalizada = String(placa).replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const payload = {
      transaction_amount: 14.99,
      description: `Consulta veicular placa ${placaNormalizada}`,
      payment_method_id: "pix",
      payer: {
        email: email || "cliente@icarsp.com.br"
      },
      external_reference: placaNormalizada
    };
    const mpResponse = await fetch("https://api.mercadopago.com/v1/payments", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "X-Idempotency-Key": import_crypto.default.randomUUID()
      },
      body: JSON.stringify(payload)
    });
    const mpData = await mpResponse.json();
    if (!mpResponse.ok) {
      return {
        statusCode: mpResponse.status === 429 ? 429 : 500,
        body: JSON.stringify({
          error: mpResponse.status === 429 ? "Muitas tentativas de gerar PIX em pouco tempo. Aguarde alguns minutos e tente novamente." : "Erro ao criar pagamento",
          details: mpData
        })
      };
    }
    const paymentId = String(mpData.id);
    if (!paymentId) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Mercado Pago n\xE3o retornou paymentId",
          details: mpData
        })
      };
    }
    const payloadSupabase = {
      payment_id: paymentId,
      placa: placaNormalizada,
      status: "pending",
      customer_email: email || null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log("SUPABASE_URL em uso:", supabaseUrl);
    console.log("Tentando salvar no Supabase:", payloadSupabase);
    const { data: insertedData, error: insertError } = await supabase.from("vehicle_reports").upsert(payloadSupabase).select();
    console.log("Resposta Supabase data:", insertedData);
    console.log("Resposta Supabase error:", insertError);
    if (insertError) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Erro ao salvar pagamento no Supabase",
          details: insertError.message || insertError
        })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        paymentId,
        payment_id: paymentId,
        status: mpData.status || "pending",
        qr_code: mpData.point_of_interaction?.transaction_data?.qr_code || null,
        qr_code_base64: mpData.point_of_interaction?.transaction_data?.qr_code_base64 || null,
        pix_copia_e_cola: mpData.point_of_interaction?.transaction_data?.qr_code || null,
        ticket_url: mpData.transaction_details?.external_resource_url || null
      })
    };
  } catch (error) {
    console.error("Erro interno create-mp-payment:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Erro ao salvar pagamento no Supabase",
        details: error.message || String(error)
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
