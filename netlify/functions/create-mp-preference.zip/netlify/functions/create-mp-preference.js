var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var create_mp_preference_exports = {};
__export(create_mp_preference_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_mp_preference_exports);
var import_crypto = __toESM(require("crypto"), 1);
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  try {
    const { placa, email } = JSON.parse(event.body || "{}");
    if (!placa) {
      return { statusCode: 400, body: JSON.stringify({ error: "Placa obrigat\xF3ria" }) };
    }
    const accessToken = process.env.MP_ACCESS_TOKEN;
    const siteUrl = process.env.SITE_URL;
    if (!accessToken || !siteUrl) {
      return { statusCode: 500, body: JSON.stringify({ error: "Configura\xE7\xE3o incompleta do servidor" }) };
    }
    const placaNormalizada = String(placa).replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const preference = {
      items: [{
        id: "consulta-veicular",
        title: `Consulta Veicular - Placa ${placaNormalizada}`,
        quantity: 1,
        unit_price: 19.99,
        currency_id: "BRL"
      }],
      payer: {
        email: email || "cliente@icarsp.com.br"
      },
      back_urls: {
        success: `${siteUrl}/resultado.html`,
        failure: `${siteUrl}/?erro=pagamento`,
        pending: `${siteUrl}/resultado.html`
      },
      auto_return: "approved",
      external_reference: placaNormalizada,
      notification_url: `${siteUrl}/.netlify/functions/mp-webhook`,
      statement_descriptor: "ICARSP"
    };
    const mpResponse = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "X-Idempotency-Key": import_crypto.default.randomUUID()
      },
      body: JSON.stringify(preference)
    });
    const mpData = await mpResponse.json();
    if (!mpResponse.ok) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Erro ao criar prefer\xEAncia de pagamento", details: mpData })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        preferenceId: mpData.id,
        init_point: mpData.init_point
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erro interno", details: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
