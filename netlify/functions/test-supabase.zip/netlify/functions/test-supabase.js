var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var test_supabase_exports = {};
__export(test_supabase_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(test_supabase_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler() {
  try {
    const { data, error } = await supabase.from("vehicle_reports").select("payment_id, placa, status").limit(1);
    if (error) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: "Erro ao consultar Supabase",
          details: error
        })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: "Conex\xE3o com Supabase OK",
        data
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: "Falha de conex\xE3o com Supabase",
        details: error.message || String(error)
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
