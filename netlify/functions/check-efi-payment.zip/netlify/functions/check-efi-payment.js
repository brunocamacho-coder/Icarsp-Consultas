var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var check_efi_payment_exports = {};
__export(check_efi_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(check_efi_payment_exports);
var import_https = __toESM(require("https"), 1);
var import_node_fetch = __toESM(require("node-fetch"), 1);
const EFI_BASE_URL = "https://pix.api.efipay.com.br";
function getAgent() {
  const certBuf = Buffer.from((process.env.EFI_CERT_BASE64 || "").trim(), "base64");
  return new import_https.default.Agent({ pfx: certBuf, passphrase: "" });
}
async function getToken(agent) {
  const credentials = Buffer.from(
    `${process.env.EFI_CLIENT_ID}:${process.env.EFI_CLIENT_SECRET}`
  ).toString("base64");
  const res = await (0, import_node_fetch.default)(`${EFI_BASE_URL}/oauth/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ grant_type: "client_credentials" }),
    agent
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Erro ao obter token Ef\xED: ${JSON.stringify(data)}`);
  return data.access_token;
}
async function handler(event) {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  const txid = event.queryStringParameters?.payment_id;
  const tipo = event.queryStringParameters?.tipo || "";
  if (!txid) {
    return { statusCode: 400, body: JSON.stringify({ error: "payment_id obrigat\xF3rio" }) };
  }
  try {
    const agent = getAgent();
    const token = await getToken(agent);
    const res = await (0, import_node_fetch.default)(`${EFI_BASE_URL}/v2/cob/${txid}`, {
      headers: { Authorization: `Bearer ${token}` },
      agent
    });
    const data = await res.json();
    if (!res.ok) throw new Error(`Ef\xED check error: ${JSON.stringify(data)}`);
    const status = data.status || "ATIVA";
    const pago = status === "CONCLUIDA";
    const isContrato = tipo === "contrato" || tipo === "contrato_reserva";
    if (pago && !isContrato) {
      try {
        await (0, import_node_fetch.default)(`${process.env.SITE_URL}/.netlify/functions/generate-report`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ paymentId: txid })
        });
      } catch (e) {
        console.error("Erro ao disparar generate-report:", e);
      }
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, payment_id: txid, status, pago })
    };
  } catch (error) {
    console.error("Erro check-efi-payment:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erro ao verificar pagamento", details: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
