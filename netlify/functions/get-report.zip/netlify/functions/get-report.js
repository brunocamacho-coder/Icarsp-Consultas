var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_report_exports = {};
__export(get_report_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_report_exports);
var import_vehicle_provider = require("./providers/vehicle-provider.js");
function normalizarPlaca(valor = "") {
  return String(valor).replace(/[^a-zA-Z0-9]/g, "").toUpperCase().trim();
}
const handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" })
    };
  }
  try {
    const placa = normalizarPlaca(event.queryStringParameters?.placa || "");
    if (!placa || placa.length < 7) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ error: "Placa inv\xE1lida" })
      };
    }
    const report = await (0, import_vehicle_provider.getVehicleReportByPlate)(placa);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(report)
    };
  } catch (error) {
    console.error("Erro em get-report:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Erro ao gerar relat\xF3rio",
        details: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
