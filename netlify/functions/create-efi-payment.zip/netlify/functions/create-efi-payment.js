var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var create_efi_payment_exports = {};
__export(create_efi_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_efi_payment_exports);
var import_https = __toESM(require("https"), 1);
var import_node_fetch = __toESM(require("node-fetch"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const EFI_BASE_URL = "https://pix.api.efipay.com.br";
function getAgent() {
  const certBuf = Buffer.from((process.env.EFI_CERT_BASE64 || "").trim(), "base64");
  return new import_https.default.Agent({ pfx: certBuf, passphrase: "" });
}
async function getToken(agent) {
  const credentials = Buffer.from(
    `${process.env.EFI_CLIENT_ID}:${process.env.EFI_CLIENT_SECRET}`
  ).toString("base64");
  const res = await (0, import_node_fetch.default)(`${EFI_BASE_URL}/oauth/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ grant_type: "client_credentials" }),
    agent
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Erro ao obter token Ef\xED: ${JSON.stringify(data)}`);
  return data.access_token;
}
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  try {
    const { placa, email } = JSON.parse(event.body || "{}");
    if (!placa) {
      return { statusCode: 400, body: JSON.stringify({ error: "Placa obrigat\xF3ria" }) };
    }
    const placaNormalizada = String(placa).replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    const txid = import_crypto.default.randomUUID().replace(/-/g, "");
    const agent = getAgent();
    const token = await getToken(agent);
    const cobPayload = {
      calendario: { expiracao: 3600 },
      valor: { original: "14.99" },
      chave: process.env.EFI_PIX_KEY,
      solicitacaoPagador: `Consulta veicular placa ${placaNormalizada}`
    };
    const cobRes = await (0, import_node_fetch.default)(`${EFI_BASE_URL}/v2/cob/${txid}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(cobPayload),
      agent
    });
    const cobData = await cobRes.json();
    if (!cobRes.ok) throw new Error(`Ef\xED cob error: ${JSON.stringify(cobData)}`);
    const supabase = (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    await supabase.from("vehicle_reports").upsert({
      payment_id: txid,
      placa: placaNormalizada,
      status: "pending",
      customer_email: email || null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        paymentId: txid,
        payment_id: txid,
        status: "pending",
        qr_code: cobData.pixCopiaECola,
        pix_copia_e_cola: cobData.pixCopiaECola
      })
    };
  } catch (error) {
    console.error("Erro create-efi-payment:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erro ao criar pagamento PIX", details: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
