var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var vehicle_provider_exports = {};
__export(vehicle_provider_exports, {
  getVehicleBasicReportByPlate: () => getVehicleBasicReportByPlate,
  getVehicleReportByPlate: () => getVehicleReportByPlate
});
module.exports = __toCommonJS(vehicle_provider_exports);
var import_node_fetch = __toESM(require("node-fetch"), 1);
const API_KEY = process.env.CONSULTARPLACA_API_KEY;
const EMAIL = process.env.CONSULTARPLACA_EMAIL;
const cache = /* @__PURE__ */ new Map();
const CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
function normalizarPlaca(placa = "") {
  return String(placa).replace(/[^A-Za-z0-9]/g, "").toUpperCase().trim();
}
function safe(value, fallback = "-") {
  return value ?? fallback;
}
function formatarPrecoFipe(valor) {
  if (!valor || isNaN(Number(valor))) return "-";
  return Number(valor).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}
function getCache(key) {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() - item.timestamp > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  return item.value;
}
function setCache(key, value) {
  cache.set(key, {
    value,
    timestamp: Date.now()
  });
}
async function consultarEndpoint(url) {
  if (!API_KEY || !EMAIL) {
    throw new Error("CONSULTARPLACA_API_KEY ou CONSULTARPLACA_EMAIL n\xE3o configurados.");
  }
  const basicAuth = Buffer.from(`${EMAIL}:${API_KEY}`).toString("base64");
  const response = await (0, import_node_fetch.default)(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Basic ${basicAuth}`
    }
  });
  const text = await response.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Resposta inv\xE1lida da API Consultar Placa: ${text?.slice(0, 300) || "vazia"}`);
  }
  if (!response.ok) {
    throw new Error(data?.mensagem || data?.message || `Falha na API externa (${response.status})`);
  }
  if (data?.status !== "ok") {
    throw new Error(data?.mensagem || "A API retornou erro ao consultar a placa.");
  }
  return data;
}
async function consultarDadosBasicos(placa) {
  const url = `https://api.consultarplaca.com.br/v2/consultarPlaca?placa=${encodeURIComponent(placa)}`;
  return consultarEndpoint(url);
}
async function consultarPrecoFipe(placa) {
  const url = `https://api.consultarplaca.com.br/v2/consultarPrecoFipe?placa=${encodeURIComponent(placa)}`;
  return consultarEndpoint(url);
}
async function consultarProprietarioAtual(placa) {
  const url = `https://api.consultarplaca.com.br/v2/consultarProprietarioAtual?placa=${encodeURIComponent(placa)}`;
  return consultarEndpoint(url);
}
async function consultarGravame(placa) {
  const url = `https://api.consultarplaca.com.br/v2/consultarGravame?placa=${encodeURIComponent(placa)}`;
  return consultarEndpoint(url);
}
async function consultarRenainf(placa) {
  const url = `https://api.consultarplaca.com.br/v2/consultarRegistrosInfracoesRenainf?placa=${encodeURIComponent(placa)}`;
  return consultarEndpoint(url);
}
function mapearDadosBasicos(placa, apiData) {
  const dadosVeiculo = apiData?.dados?.informacoes_veiculo?.dados_veiculo || {};
  const marca = safe(dadosVeiculo?.marca);
  const modelo = safe(dadosVeiculo?.modelo);
  const marcaModelo = marca !== "-" && modelo !== "-" ? `${marca} / ${modelo}` : safe(modelo !== "-" ? modelo : marca);
  const anoFabricacao = safe(dadosVeiculo?.ano_fabricacao || dadosVeiculo?.ano_frabricacao);
  const anoModelo = safe(dadosVeiculo?.ano_modelo);
  const ano = anoFabricacao !== "-" && anoModelo !== "-" ? `${anoFabricacao}/${anoModelo}` : safe(anoModelo !== "-" ? anoModelo : anoFabricacao);
  return {
    placa,
    basic: {
      marca_modelo: marcaModelo,
      ano,
      combustivel: safe(dadosVeiculo?.combustivel),
      cidade_registro: safe(dadosVeiculo?.municipio),
      uf_registro: safe(dadosVeiculo?.uf_municipio),
      cor: safe(dadosVeiculo?.cor)
    },
    vehicle: {
      marca_modelo: marcaModelo,
      ano,
      cor: safe(dadosVeiculo?.cor),
      combustivel: safe(dadosVeiculo?.combustivel),
      fipe: "-",
      chassi: safe(dadosVeiculo?.chassi),
      renavam: "Dispon\xEDvel no relat\xF3rio completo"
    },
    status: {
      roubo_furto: "N\xE3o consta",
      leilao: "N\xE3o consta",
      debitos: "Verifica\xE7\xE3o dispon\xEDvel no relat\xF3rio completo",
      restricoes: "Verifica\xE7\xE3o dispon\xEDvel no relat\xF3rio completo",
      gravame: "Verifica\xE7\xE3o dispon\xEDvel no relat\xF3rio completo",
      licenciamento_ipva: "Verifica\xE7\xE3o dispon\xEDvel no relat\xF3rio completo"
    },
    details: {
      instituicao_credora: "Dispon\xEDvel no relat\xF3rio completo",
      detalhes_bloqueio: "Dispon\xEDvel no relat\xF3rio completo",
      proprietario_atual: "Dispon\xEDvel no relat\xF3rio completo",
      documento_proprietario: "Dispon\xEDvel no relat\xF3rio completo",
      tipo_documento_proprietario: "Dispon\xEDvel no relat\xF3rio completo",
      data_registro_gravame: "Dispon\xEDvel no relat\xF3rio completo",
      codigo_fipe: "Dispon\xEDvel no relat\xF3rio completo",
      modelo_versao_fipe: "Dispon\xEDvel no relat\xF3rio completo",
      mes_referencia_fipe: "Dispon\xEDvel no relat\xF3rio completo",
      quantidade_infracoes_renainf: "Dispon\xEDvel no relat\xF3rio completo",
      valor_total_infracoes_renainf: "Dispon\xEDvel no relat\xF3rio completo",
      resumo_infracoes_renainf: "Dispon\xEDvel no relat\xF3rio completo"
    },
    offer: {
      price: "R$ 19,99"
    }
  };
}
function aplicarDadosFipe(report, fipeData) {
  const informacoesFipe = fipeData?.dados?.informacoes_fipe;
  if (Array.isArray(informacoesFipe) && informacoesFipe.length > 0) {
    const primeiro = informacoesFipe[0];
    report.vehicle.fipe = formatarPrecoFipe(primeiro?.preco);
    report.details.codigo_fipe = safe(primeiro?.codigo_fipe);
    report.details.modelo_versao_fipe = safe(primeiro?.modelo_versao);
    report.details.mes_referencia_fipe = safe(primeiro?.mes_referencia);
  }
  return report;
}
function aplicarDadosProprietario(report, proprietarioData) {
  const proprietario = proprietarioData?.dados?.proprietario_atual || {};
  report.details.proprietario_atual = safe(proprietario?.nome, "N\xE3o informado");
  report.details.documento_proprietario = safe(proprietario?.documento, "N\xE3o informado");
  report.details.tipo_documento_proprietario = safe(proprietario?.tipo_documento, "N\xE3o informado");
  return report;
}
function aplicarDadosGravame(report, gravameData) {
  const gravame = gravameData?.dados?.gravame || {};
  const possuiGravame = String(gravame?.possui_gravame || "").toLowerCase();
  const registro = gravame?.registro || null;
  if (possuiGravame === "sim") {
    report.status.gravame = "Gravame ativo";
    report.details.instituicao_credora = safe(registro?.agente_financeiro?.nome, "N\xE3o informado");
    report.details.data_registro_gravame = safe(registro?.data_registro, "N\xE3o informado");
    report.details.detalhes_bloqueio = safe(registro?.situacao, "N\xE3o informado");
  } else if (possuiGravame === "nao") {
    report.status.gravame = "N\xE3o possui gravame";
    report.details.instituicao_credora = "N\xE3o consta";
    report.details.data_registro_gravame = "N\xE3o consta";
    report.details.detalhes_bloqueio = "N\xE3o consta";
  } else {
    report.status.gravame = "Indispon\xEDvel no momento";
    report.details.instituicao_credora = "Indispon\xEDvel";
    report.details.data_registro_gravame = "Indispon\xEDvel";
    report.details.detalhes_bloqueio = "Indispon\xEDvel";
  }
  return report;
}
function aplicarDadosRenainf(report, renainfData) {
  const infracoesData = renainfData?.dados?.registro_debitos_por_infracoes_renainf?.infracoes_renainf || {};
  const possuiInfracoes = String(infracoesData?.possui_infracoes || "").toLowerCase();
  const infracoes = Array.isArray(infracoesData?.infracoes) ? infracoesData.infracoes : [];
  if (possuiInfracoes === "sim" && infracoes.length > 0) {
    report.status.debitos = `Constam ${infracoes.length} infra\xE7\xE3o(\xF5es) RENAINF`;
    let total = 0;
    const resumo = infracoes.slice(0, 3).map((item) => {
      const dados = item?.dados_infracao || {};
      const valorAplicado = String(dados?.valor_aplicado || "0").replace(",", ".");
      const valorNumero = parseFloat(valorAplicado);
      if (!isNaN(valorNumero)) {
        total += valorNumero;
      }
      return `${safe(dados?.infracao, "Infra\xE7\xE3o n\xE3o identificada")} (${safe(dados?.municipio, "Munic\xEDpio n\xE3o informado")})`;
    });
    report.details.quantidade_infracoes_renainf = String(infracoes.length);
    report.details.valor_total_infracoes_renainf = total.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    });
    report.details.resumo_infracoes_renainf = resumo.join(" | ");
  } else if (possuiInfracoes === "nao") {
    report.status.debitos = "N\xE3o consta";
    report.details.quantidade_infracoes_renainf = "0";
    report.details.valor_total_infracoes_renainf = "R$ 0,00";
    report.details.resumo_infracoes_renainf = "N\xE3o consta";
  } else {
    report.status.debitos = "Indispon\xEDvel no momento";
    report.details.quantidade_infracoes_renainf = "-";
    report.details.valor_total_infracoes_renainf = "-";
    report.details.resumo_infracoes_renainf = "Indispon\xEDvel";
  }
  return report;
}
async function getVehicleBasicReportByPlate(placaInformada) {
  const placa = normalizarPlaca(placaInformada);
  if (!placa || placa.length < 7) {
    throw new Error("Placa inv\xE1lida.");
  }
  const apiData = await consultarDadosBasicos(placa);
  const report = mapearDadosBasicos(placa, apiData);
  return {
    success: true,
    placa: report.placa,
    basic: report.basic,
    teaser: {
      alertCount: 12,
      message: "Identificamos verifica\xE7\xF5es adicionais e informa\xE7\xF5es complementares liberadas somente no relat\xF3rio completo."
    },
    offer: report.offer
  };
}
async function getVehicleReportByPlate(placaInformada) {
  const placa = normalizarPlaca(placaInformada);
  if (!placa || placa.length < 7) {
    throw new Error("Placa inv\xE1lida.");
  }
  const cacheKey = `report:${placa}`;
  const cached = getCache(cacheKey);
  if (cached) {
    return cached;
  }
  const apiData = await consultarDadosBasicos(placa);
  const report = mapearDadosBasicos(placa, apiData);
  try {
    const fipeData = await consultarPrecoFipe(placa);
    aplicarDadosFipe(report, fipeData);
  } catch (error) {
    console.warn("FIPE n\xE3o dispon\xEDvel para esta placa:", error.message);
  }
  try {
    const proprietarioData = await consultarProprietarioAtual(placa);
    aplicarDadosProprietario(report, proprietarioData);
  } catch (error) {
    console.warn("Propriet\xE1rio atual n\xE3o dispon\xEDvel para esta placa:", error.message);
  }
  try {
    const gravameData = await consultarGravame(placa);
    aplicarDadosGravame(report, gravameData);
  } catch (error) {
    console.warn("Gravame n\xE3o dispon\xEDvel para esta placa:", error.message);
  }
  try {
    const renainfData = await consultarRenainf(placa);
    aplicarDadosRenainf(report, renainfData);
  } catch (error) {
    console.warn("RENAINF n\xE3o dispon\xEDvel para esta placa:", error.message);
  }
  setCache(cacheKey, report);
  return report;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getVehicleBasicReportByPlate,
  getVehicleReportByPlate
});
