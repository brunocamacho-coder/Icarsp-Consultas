var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var enviar_contrato_exports = {};
__export(enviar_contrato_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(enviar_contrato_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  try {
    const { pdfBase64, email, telefone, nome, placa, tipoContrato } = JSON.parse(event.body || "{}");
    if (!email || !pdfBase64) {
      return { statusCode: 400, body: JSON.stringify({ error: "email e pdfBase64 s\xE3o obrigat\xF3rios" }) };
    }
    await supabase.from("leads_contratos").upsert({
      nome: nome || null,
      email: email.toLowerCase(),
      telefone: telefone || null,
      placa: placa || null,
      tipo_contrato: tipoContrato || null,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    const mailerKey = process.env.MAILERSEND_API_KEY;
    if (!mailerKey) {
      return { statusCode: 500, body: JSON.stringify({ error: "MAILERSEND_API_KEY n\xE3o configurada" }) };
    }
    const nomeArquivo = tipoContrato === "reserva_dominio" ? "CONTRATO RESERVA DE DOMINIO.pdf" : "CONTRATO DE COMPRA E VENDA.pdf";
    const mailerResponse = await fetch("https://api.mailersend.com/v1/email", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${mailerKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: { email: "contratos@icarsp.com.br", name: "iCarSP" },
        reply_to: { email: "icarspconsultas@gmail.com", name: "iCarSP" },
        to: [{ email, name: nome || email }],
        subject: `Seu contrato iCarSP \u2014 ${placa || "Ve\xEDculo"}`,
        html: `
          <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#fff;padding:32px;border-radius:8px;">
            <h2 style="color:#b45309;">iCarSP \u2014 Servi\xE7os Automotivos</h2>
            <p>Ol\xE1${nome ? ", " + nome : ""}!</p>
            <p>Segue em anexo o seu contrato gerado pela plataforma iCarSP.</p>
            <p style="background:#fef3c7;border-left:4px solid #d97706;padding:12px;border-radius:4px;">
              <strong>Guarde este arquivo!</strong> Ele tem validade jur\xEDdica nos termos do C\xF3digo Civil Brasileiro.
            </p>
            <p style="color:#666;font-size:0.85rem;margin-top:24px;">
              iCarSP \u2014 Despachante Documentalista CRDD 005636-7<br>
              icarspconsultas@gmail.com | www.icarsp.com.br
            </p>
          </div>
        `,
        attachments: [
          {
            filename: nomeArquivo,
            content: pdfBase64,
            disposition: "attachment"
          }
        ]
      })
    });
    if (!mailerResponse.ok) {
      const err = await mailerResponse.json();
      console.error("Erro MailerSend:", err);
      return { statusCode: 500, body: JSON.stringify({ error: "Erro ao enviar email", details: err }) };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Email enviado com sucesso" })
    };
  } catch (error) {
    console.error("Erro em enviar-contrato:", error);
    return { statusCode: 500, body: JSON.stringify({ error: "Erro interno", details: error.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
