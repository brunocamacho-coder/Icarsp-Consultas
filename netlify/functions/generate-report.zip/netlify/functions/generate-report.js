var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var generate_report_exports = {};
__export(generate_report_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_report_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
function basicAuthHeader() {
  const email = process.env.CONSULTARPLACA_EMAIL;
  const apiKey = process.env.CONSULTARPLACA_API_KEY;
  return "Basic " + Buffer.from(`${email}:${apiKey}`).toString("base64");
}
async function consultarEndpoint(endpoint, placa, authHeader) {
  const response = await fetch(
    `https://api.consultarplaca.com.br/v2/${endpoint}?placa=${encodeURIComponent(placa)}`,
    {
      method: "GET",
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json"
      }
    }
  );
  const text = await response.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    throw new Error(`${endpoint} falhou com status ${response.status}`);
  }
  return data;
}
async function handler(event) {
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" })
      };
    }
    const { paymentId } = JSON.parse(event.body || "{}");
    if (!paymentId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "paymentId obrigat\xF3rio" })
      };
    }
    const { data: record, error: fetchError } = await supabase.from("vehicle_reports").select("*").eq("payment_id", String(paymentId)).single();
    if (fetchError || !record) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Pagamento n\xE3o encontrado" })
      };
    }
    if (record.status === "ready" && record.report) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          cached: true,
          status: "ready",
          report: record.report
        })
      };
    }
    if (record.status === "processing") {
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          processing: true,
          status: "processing",
          message: "Relat\xF3rio j\xE1 est\xE1 sendo processado"
        })
      };
    }
    const { data: lockedRows, error: lockError } = await supabase.from("vehicle_reports").update({
      status: "processing",
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("payment_id", String(paymentId)).eq("status", "pending").select();
    if (lockError) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Erro ao travar processamento do relat\xF3rio",
          details: lockError.message
        })
      };
    }
    if (!lockedRows || lockedRows.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          processing: true,
          status: "processing",
          message: "Outra execu\xE7\xE3o j\xE1 iniciou o relat\xF3rio"
        })
      };
    }
    const placa = record.placa;
    const authHeader = basicAuthHeader();
    const veiculo = await consultarEndpoint("consultarPlaca", placa, authHeader);
    const resultados = await Promise.allSettled([
      consultarEndpoint("consultarProprietarioAtual", placa, authHeader),
      consultarEndpoint("consultarPrecoFipe", placa, authHeader)
    ]);
    const proprietarioAtual = resultados[0].status === "fulfilled" ? resultados[0].value : null;
    const precoFipe = resultados[1].status === "fulfilled" ? resultados[1].value : null;
    const report = {
      placa,
      veiculo,
      proprietarioAtual,
      precoFipe,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      custoTotalEstimado: 8.2
    };
    const { error: updateError } = await supabase.from("vehicle_reports").update({
      status: "ready",
      report,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("payment_id", String(paymentId));
    if (updateError) {
      await supabase.from("vehicle_reports").update({
        status: "error",
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("payment_id", String(paymentId));
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Erro ao salvar relat\xF3rio",
          details: updateError.message
        })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        cached: false,
        status: "ready",
        report
      })
    };
  } catch (error) {
    console.error("Erro em generate-report:", error);
    try {
      const { paymentId } = JSON.parse(event.body || "{}");
      if (paymentId) {
        await supabase.from("vehicle_reports").update({
          status: "error",
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("payment_id", String(paymentId));
      }
    } catch (_) {
    }
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Erro ao gerar relat\xF3rio",
        details: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
