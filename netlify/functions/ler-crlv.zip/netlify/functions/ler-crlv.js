var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ler_crlv_exports = {};
__export(ler_crlv_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ler_crlv_exports);
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" }) };
  }
  try {
    const { imageBase64, mediaType } = JSON.parse(event.body || "{}");
    if (!imageBase64) {
      return { statusCode: 400, body: JSON.stringify({ error: "Imagem n\xE3o enviada" }) };
    }
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, body: JSON.stringify({ error: "ANTHROPIC_API_KEY n\xE3o configurada" }) };
    }
    const isPDF = mediaType === "application/pdf";
    const content = [
      isPDF ? {
        type: "document",
        source: {
          type: "base64",
          media_type: "application/pdf",
          data: imageBase64
        }
      } : {
        type: "image",
        source: {
          type: "base64",
          media_type: mediaType || "image/jpeg",
          data: imageBase64
        }
      },
      {
        type: "text",
        text: `Voc\xEA \xE9 um especialista em documentos veiculares brasileiros. Analise este documento CRLV (Certificado de Registro e Licenciamento de Ve\xEDculo) e extraia os dados. Retorne APENAS um JSON v\xE1lido, sem markdown, sem explica\xE7\xF5es, sem texto adicional. Se n\xE3o conseguir ler algum campo, deixe como string vazia "".

Formato exato do JSON:
{
  "placa": "",
  "marca_modelo": "",
  "ano_fabricacao": "",
  "ano_modelo": "",
  "cor": "",
  "combustivel": "",
  "chassi": "",
  "renavam": ""
}`
      }
    ];
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "pdfs-2024-09-25"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1e3,
        messages: [{ role: "user", content }]
      })
    });
    if (!response.ok) {
      const error = await response.json();
      console.error("Erro API Anthropic:", JSON.stringify(error));
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Erro na API Anthropic", details: error })
      };
    }
    const data = await response.json();
    const texto = data.content?.[0]?.text || "{}";
    console.log("Resposta IA:", texto);
    let dadosVeiculo;
    try {
      dadosVeiculo = JSON.parse(texto.replace(/```json|```/g, "").trim());
    } catch (e) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Erro ao interpretar resposta da IA", raw: texto })
      };
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ success: true, dados: dadosVeiculo })
    };
  } catch (error) {
    console.error("Erro na fun\xE7\xE3o ler-crlv:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erro interno", details: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
