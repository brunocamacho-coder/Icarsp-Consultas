var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_saved_report_exports = {};
__export(get_saved_report_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_saved_report_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler(event) {
  try {
    if (event.httpMethod !== "GET") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido" })
      };
    }
    const paymentId = event.queryStringParameters?.paymentId;
    if (!paymentId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "paymentId obrigat\xF3rio" })
      };
    }
    const { data, error } = await supabase.from("vehicle_reports").select("status, report, placa, updated_at").eq("payment_id", String(paymentId)).single();
    if (error || !data) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Relat\xF3rio n\xE3o encontrado" })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        status: data.status,
        placa: data.placa,
        report: data.report || null,
        updatedAt: data.updated_at
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Erro ao buscar relat\xF3rio salvo",
        details: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
